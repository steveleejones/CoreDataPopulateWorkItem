﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreDataPopulateWorkItem.Models
{
    internal class ResortAirport
    {
        public int AirportId { get; set; }
        public int ResortId { get; set; }
        public string ResortName { get; set; }
    }
}
