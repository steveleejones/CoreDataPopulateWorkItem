﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreDataPopulateWorkItem.Models
{
    internal class PropertyFacilityList
    {
        public int PropertyReferenceId { get; set; }
        public int LanguageId { get; set; }
        public string FacilitiesList { get; set; }
    }
}
