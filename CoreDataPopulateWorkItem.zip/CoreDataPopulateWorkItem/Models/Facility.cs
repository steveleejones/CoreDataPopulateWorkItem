﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreDataPopulateWorkItem.Models
{
    internal class Facility
    {
        public int FacilityId { get; set; }
        public int FacilityGroupId { get; set; }
        public int LanguageId { get; set; }
    }
}
