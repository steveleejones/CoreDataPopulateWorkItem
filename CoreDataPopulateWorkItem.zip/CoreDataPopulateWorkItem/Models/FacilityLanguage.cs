﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreDataPopulateWorkItem.Models
{
    internal class FacilityLanguage
    {
        public int FacilityId { get; set; }
        public int LanguageId { get; set; }
        public string FacilityDescription { get; set; }
    }
}
